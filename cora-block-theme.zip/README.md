# Cora Block Theme

A WordPress block theme starter that includes common templates (`index`, `single`, `page`, `archive`, `search`, `404`) and extra page templates with title and hero sections.

## Structure

```
cora-block-theme/
├── parts/
│   ├── footer.html
│   ├── header-hero.html
│   └── header.html
├── templates/
│   ├── 404.html
│   ├── archive.html
│   ├── home.html
│   ├── index.html
│   ├── page.html
│   ├── search.html
│   ├── single.html
│   ├── template-blank.html
│   ├── template-page-w-hero.html
│   └── template-page-w-title.html
├── style.css
└── theme.json
```

## Use locally (WordPress)
1. Zip the theme directory.
2. Upload via **Appearance → Themes → Add New → Upload Theme**.
3. Activate it and edit in the Site Editor.

## Make this a GitHub template
1. Create a new public repository on GitHub named `cora-block-theme`.
2. Upload the files in this folder to that repository.
3. In the repo settings, check **Template repository**.
4. Now others can click **Use this template** to start their own project.

## License
MIT
